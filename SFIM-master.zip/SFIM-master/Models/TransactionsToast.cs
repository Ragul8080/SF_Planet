using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspnetCoreMvcFull.Models
{
    public class TransactionsToast
    {
    public string? Message { get; set; }
    public string? CssClass { get; set; }
    }
}
