﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {
    $('#profitPerMarketplaceSku, #profitPerOrder').DataTable({
        dom: 'Bfrtip', // Enable buttons
        buttons: [
            {
                extend: 'collection',
                text: 'Export', // The text for the dropdown button
                buttons: [
                    'print', 'csv', 'excel', 'pdf', 'copy'
                ]
            }
        ]
    });
});
