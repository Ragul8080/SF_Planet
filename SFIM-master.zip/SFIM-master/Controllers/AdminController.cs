using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SFIM.Models;

namespace SFIM.Controllers;

public class AdminController : Controller
{
  public IActionResult Users() => View();
  public IActionResult ViewAccount() => View();
  public IActionResult Roles() => View();
  public IActionResult Permission() => View();
  public IActionResult StoreDetails() => View();
  public IActionResult AccountSettings() => View();
  public IActionResult EmailSettings() => View();

}
