// Controllers/HomeController.cs
using Microsoft.AspNetCore.Mvc;
using SFIM.Models;
using System.Diagnostics;

namespace SFIM.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // Replace this logic with your actual authentication code
            if (username == "admin" && password == "password")
            {
                return RedirectToAction("Index"); // Redirect to Index if login is successful
            }

            // Display an error message if the login fails
            ModelState.AddModelError(string.Empty, "Invalid username or password.");
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
