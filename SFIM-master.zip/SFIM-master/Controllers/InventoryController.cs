using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SFIM.Models;

namespace SFIM.Controllers;

public class InventoryController : Controller
{
  public IActionResult ManageInventory() => View();
}
