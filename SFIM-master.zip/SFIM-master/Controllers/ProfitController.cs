using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SFIM.Models;

namespace SFIM.Controllers;

public class ProfitController : Controller
{
  public IActionResult ProfitPerMarketplaceSku() => View();
  public IActionResult ProfitPerOrder() => View();
}
