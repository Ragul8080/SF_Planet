using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SFIM.Models;

namespace SFIM.Controllers;

public class DashboardsController : Controller
{
  public IActionResult Index() => View();
  public IActionResult CRM() => View();
}
